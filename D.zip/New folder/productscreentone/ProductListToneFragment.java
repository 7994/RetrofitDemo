package com.builderfly.sparkup.productscreens.productscreentone;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.builderfly.customviews.CustomTextView;
import com.builderfly.network.OkHttpInterface;
import com.builderfly.network.OkHttpRequest;
import com.builderfly.network.RequestParam;
import com.builderfly.sparkup.R;
import com.builderfly.sparkup.dashboardscreens.dashboardscreentone.DashboardToneActivity;
import com.builderfly.sparkup.orderlistscreens.orderlistscreentone.CustomerCartListToneFragment;
import com.builderfly.sparkup.searchproductscreens.searchproductscreentone.SearchProductToneFragment;
import com.builderfly.utils.AppLog;
import com.builderfly.utils.AppSharedPref;
import com.builderfly.utils.CommonUtils;
import com.builderfly.utils.Constants;
import com.builderfly.utils.SupportFragmentUtil;
import com.google.gson.Gson;

public class ProductListToneFragment extends Fragment implements View.OnClickListener, OkHttpInterface {

    private static final String TAG = ProductListToneFragment.class.getSimpleName();
    private Context mContext;
    private RelativeLayout mRltProductListRoot;

    // Toolbar views
    private View mToolbar;
    private ImageView mImgToolBarBack;
    private CustomTextView mTxtToolBarTitle;
    private ImageView mImgToolBarSearch;
    private ImageView mImgToolbarCart;

    private RecyclerView mRecyclerProductList;
    private int mCatId;
    private ProductListAdapter mProductListAdapter;
    private CustomTextView mTxtCount;
    private CustomTextView mTxtNoData;
    private FrameLayout mFrameItemCount;
    private ImageView mImgToolBarGridList;

    /**
     * @param
     * @return
     * @throws
     * @purpose to initialize {@link ProductListToneFragment}
     */
    public ProductListToneFragment() {
        // Required empty public constructor
    }

    /**
     * @param
     * @return Instance of {@link ProductListToneFragment}
     * @throws
     * @purpose to create instance of {@link ProductListToneFragment}
     */
    public static ProductListToneFragment newInstance() {
        return new ProductListToneFragment();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.e("Screen", "Fragment : " + TAG);
        return inflater.inflate(R.layout.fragment_product_list_tone, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((DashboardToneActivity) getActivity()).hideToolBar();
//        mImgToolBarSearch.setImageDrawable(getResources().getDrawable(R.drawable.ic_grid_black));
        mImgToolBarGridList.setImageDrawable(getResources().getDrawable(R.drawable.ic_grid_black));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ((DashboardToneActivity) getActivity()).showToolBar();
        mImgToolBarGridList.setVisibility(View.GONE);
        mImgToolBarSearch.setImageDrawable(getResources().getDrawable(R.drawable.ic_search_black));
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        findViews(view);
    }

    /**
     * @param view
     * @return
     * @throws
     * @purpose to initialize the layout fragment_product_list_tone
     */
    private void findViews(View view) {
        mRltProductListRoot = (RelativeLayout) view.findViewById(R.id.rlt_product_list_root);
        mToolbar = view.findViewById(R.id.rlt_product_list_action_bar);
        mImgToolBarBack = mToolbar.findViewById(R.id.img_toolbar_back);
        mTxtToolBarTitle = mToolbar.findViewById(R.id.txt_toolbar_title);
        mImgToolBarSearch = mToolbar.findViewById(R.id.img_toolbar_search);
        mImgToolBarGridList = mToolbar.findViewById(R.id.img_toolbar_grid_list);
        mRecyclerProductList = (RecyclerView) view.findViewById(R.id.recycler_product_list);
        mImgToolbarCart = mToolbar.findViewById(R.id.imgToolbarCart);
        mTxtCount = mToolbar.findViewById(R.id.txtCount);
        mImgToolBarGridList.setTag(R.drawable.ic_grid_black);
        mImgToolBarSearch.setVisibility(View.VISIBLE);
        mImgToolBarGridList.setVisibility(View.VISIBLE);
        mTxtToolBarTitle.setText("Product List");

        mFrameItemCount = mToolbar.findViewById(R.id.frame_item_count);
        mFrameItemCount.setVisibility(View.VISIBLE);

        mTxtNoData = (CustomTextView)view.findViewById(R.id.txtNoData);
        mTxtCount.setText(AppSharedPref.getInstance(mContext).getDataString(Constants.USER_CART_COUNT));
        setOnClickListeners();
        Bundle bundle = getArguments();
        if (bundle != null) {
            if (bundle.containsKey("catId")) {
                mCatId = (bundle.getInt("catId", 0));
                Log.e("ProductListFragment", "catId : " + mCatId);
            }
        }
//        callCatAssignedProductService("27");
        callCatAssignedProductService(String.valueOf(mCatId), AppSharedPref.getInstance(mContext).getUserId());
    }

    /**
     * @param
     * @return
     * @throws
     * @purpose to set click-listeners on views.
     */
    private void setOnClickListeners() {
        mImgToolBarSearch.setOnClickListener(this);
        mImgToolBarGridList.setOnClickListener(this);
        mImgToolBarBack.setOnClickListener(this);
        mImgToolbarCart.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.img_toolbar_grid_list:
                if ((Integer) mImgToolBarGridList.getTag() == R.drawable.ic_list_black) {
                    mImgToolBarGridList.setTag(R.drawable.ic_grid_black);
                    mImgToolBarGridList.setImageDrawable(mContext.getDrawable(R.drawable.ic_grid_black));
                    mRecyclerProductList.setLayoutManager(new LinearLayoutManager(mContext));
                } else {
                    mImgToolBarGridList.setTag(R.drawable.ic_list_black);
                    mImgToolBarGridList.setImageDrawable(mContext.getDrawable(R.drawable.ic_list_black));
                    mRecyclerProductList.setLayoutManager(new GridLayoutManager(mContext, 2));
                }
                mProductListAdapter.notifyDataSetChanged();
                break;

            case R.id.img_toolbar_search:
                SupportFragmentUtil.getInstance().replaceFragment(
                        (FragmentActivity) mContext,
                        R.id.activity_dashboard_fragment_container,
                        SearchProductToneFragment.newInstance(),
                        String.valueOf(Constants.getFragmentFromClassName(Constants.AppNavigation.strSearchProductFragmentScreen)),
//                        Constants.TAG_SEARCH_PRODUCT,
                        SupportFragmentUtil.ANIMATION_TYPE.NONE);
/*
                if ((Integer) mImgToolBarSearch.getTag() == R.drawable.ic_list_black) {
                    mImgToolBarSearch.setTag(R.drawable.ic_grid_black);
                    mImgToolBarSearch.setImageDrawable(mContext.getDrawable(R.drawable.ic_grid_black));
                    mRecyclerProductList.setLayoutManager(new LinearLayoutManager(mContext));
                } else {
                    mImgToolBarSearch.setTag(R.drawable.ic_list_black);
                    mImgToolBarSearch.setImageDrawable(mContext.getDrawable(R.drawable.ic_list_black));
                    mRecyclerProductList.setLayoutManager(new GridLayoutManager(mContext, 2));
                }
                mProductListAdapter.notifyDataSetChanged();
*/
                break;


            case R.id.img_toolbar_back:
                getActivity().getSupportFragmentManager().popBackStack();
                break;

            case R.id.imgToolbarCart:
                CustomerCartListToneFragment customerCartListToneFragment = CustomerCartListToneFragment.newInstance();
                SupportFragmentUtil.getInstance().replaceFragment(
                        (FragmentActivity) getActivity(),
                        R.id.activity_dashboard_fragment_container,
                        customerCartListToneFragment,
                        String.valueOf(Constants.getFragmentFromClassName(Constants.AppNavigation.strCustomerCartListFragmentScreen)),
                        SupportFragmentUtil.ANIMATION_TYPE.NONE);
                break;

        }
    }

    /**
     * @param strCatId
     * @return
     * @throws
     * @purpose to send request to send request to the server for Category Assigned ProductList
     */

    private void callCatAssignedProductService(String strCatId, String strUserId) {
        // Check internet connection to proceed
        if (!CommonUtils.isInternetAvailable(mContext)) {
            return;
        }
        new OkHttpRequest(getActivity(), OkHttpRequest.Method.POST,
                Constants.Urls.CAT_ASSIGN_PRO_LIST,
                RequestParam.catAssignedProductList(strCatId, strUserId),
                RequestParam.getCommonHeaderWithContentType(),
                Constants.CODE_CAT_ASSIGN_PRODUCT_LIST,
                true,
                this,
                RequestParam.getCommonHeaderWithContentType());
    }

    /**
     * @param output
     * @return
     * @throws
     * @purpose to handle response from server for AllCategories
     */

    private void handleResponseCatAssignProductList(String output) {
        AppLog.LogE("handleResponseCatAssignProductList", output);
//        printResponse(output);
        final Gson gson = new Gson();
        try {
            CatAssignedProductListModel catAssignedProductListModel = gson.fromJson(output, CatAssignedProductListModel.class);
            if (catAssignedProductListModel != null) {
                if (catAssignedProductListModel.getStatus() == 1) {
                    if(catAssignedProductListModel.getData().size()==0){
                        mTxtNoData.setText(getString(R.string.no_data));
                    }
                    mRecyclerProductList.setHasFixedSize(true);
                    mRecyclerProductList.setLayoutManager(new LinearLayoutManager(mContext));
                    mProductListAdapter = new ProductListAdapter((AppCompatActivity) getActivity(), catAssignedProductListModel.getData());
                    mRecyclerProductList.setAdapter(mProductListAdapter);
                } else {
                    mTxtNoData.setText(getString(R.string.no_data));
                    CommonUtils.displayToast(mContext, "" + catAssignedProductListModel.getMessage());
                }
            } /*else {
                Toast.makeText(mContext, "" + catAssignedProductListModel.getMessage(), Toast.LENGTH_SHORT).show();
            }*/
        } catch (Exception e) {
            e.printStackTrace();
            CommonUtils.displayToast(getActivity(), getResources().getString(R.string.str_something_went_worng));
        }
    }

    public void printResponse(String strMessage) {
        int maxLogSize = 1000;
        for (int i = 0; i <= strMessage.length() / maxLogSize; i++) {
            int start = i * maxLogSize;
            int end = (i + 1) * maxLogSize;
            end = end > strMessage.length() ? strMessage.length() : end;
            Log.e(TAG, "----> " + strMessage.substring(start, end));
        }
    }

    @Override
    public void onOkHttpStart(int requestId) {

    }

    @Override
    public void onOkHttpSuccess(int requestId, int statusCode, String response) {
        if (requestId == Constants.CODE_CAT_ASSIGN_PRODUCT_LIST) {
            handleResponseCatAssignProductList(response);
        }
    }

    @Override
    public void onOkHttpFailure(int requestId, int statusCode, String response, Throwable error) {

    }

    @Override
    public void onOkHttpFinish(int requestId) {

    }
}
