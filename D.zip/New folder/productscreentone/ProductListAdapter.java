package com.builderfly.sparkup.productscreens.productscreentone;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.builderfly.customviews.CustomTextView;
import com.builderfly.network.OkHttpInterface;
import com.builderfly.network.OkHttpRequest;
import com.builderfly.network.RequestParam;
import com.builderfly.sparkup.R;
import com.builderfly.sparkup.productdetailscreens.productdetailscreentone.ProductDetailToneFragment;
import com.builderfly.sparkup.productdetailscreens.productdetailscreentone.WishListActionsModel;
import com.builderfly.utils.AppLog;
import com.builderfly.utils.AppSharedPref;
import com.builderfly.utils.CommonUtils;
import com.builderfly.utils.Constants;
import com.builderfly.utils.SupportFragmentUtil;
import com.google.gson.Gson;

import java.util.List;

public class ProductListAdapter extends RecyclerView.Adapter<ProductListAdapter.ViewHolder> implements OkHttpInterface {
    private static final String TAG = ProductListAdapter.class.getSimpleName();
    private AppCompatActivity mContext;
    private List<CatAssignedProductListModel.CatAssignedProductListDataModel> mProductList;
    private boolean isLinear = true;
    private OkHttpInterface okHttpInterface;

    /**
     * @param mContext
     * @param mProductList
     * @return
     * @throws
     * @purpose to initialize {@link ProductListAdapter}
     */
    public ProductListAdapter(AppCompatActivity mContext, List<CatAssignedProductListModel.CatAssignedProductListDataModel> mProductList) {
        this.mContext = mContext;
        this.mProductList = mProductList;
        okHttpInterface = this;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.adapter_product_item_1, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        final CatAssignedProductListModel.CatAssignedProductListDataModel catAssignedProductListDataModel = mProductList.get(position);
        holder.mTxtProductItemNameGrid.setText(catAssignedProductListDataModel.getName());
        holder.mTxtProductItemPriceGrid.setText(String.valueOf("$" + "" + catAssignedProductListDataModel.getPrice()));
        CommonUtils.loadImage(mContext, catAssignedProductListDataModel.getImageUrl(), holder.mImgProductItem);

        Log.e("ProductlistAdapter", "isAdded in wishlist : " + catAssignedProductListDataModel.getWishlist());

        if (catAssignedProductListDataModel.getWishlist()) {
            holder.mImgProductItemLike.setTag(R.drawable.ic_favorite_selected);
            holder.mImgProductItemLike.setImageDrawable(mContext.getDrawable(R.drawable.ic_favorite_selected));
        } else {
            holder.mImgProductItemLike.setTag(R.drawable.ic_favorite);
            holder.mImgProductItemLike.setImageDrawable(mContext.getDrawable(R.drawable.ic_favorite));
        }

//        holder.mImgProductItemLike.setTag(R.drawable.ic_favorite);
        holder.mImgProductItemLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((Integer) holder.mImgProductItemLike.getTag() == R.drawable.ic_favorite_selected) {
//                    callWishListActionsService("5", "4", "1", "remove");
                    callWishListActionsService(AppSharedPref.getInstance(mContext).getUserId(), catAssignedProductListDataModel.getProdId(), "1", "remove");
                    holder.mImgProductItemLike.setTag(R.drawable.ic_favorite);
                    holder.mImgProductItemLike.setImageDrawable(mContext.getDrawable(R.drawable.ic_favorite));
                } else {
//                    callWishListActionsService("5", "4", "1", "add");
                    callWishListActionsService(AppSharedPref.getInstance(mContext).getUserId(), catAssignedProductListDataModel.getProdId(), "1", "add");
//                    callWishListActionsService("5", "4", "1", "add");
                    holder.mImgProductItemLike.setTag(R.drawable.ic_favorite_selected);
                    holder.mImgProductItemLike.setImageDrawable(mContext.getDrawable(R.drawable.ic_favorite_selected));
                }
            }
        });

        if (!isLinear) {
            holder.mRltProductItemNamePriceLinearRoot.setVisibility(View.VISIBLE);
            holder.mRltProductItemNamePriceGridRoot.setVisibility(View.GONE);
        } else {
            holder.mRltProductItemNamePriceGridRoot.setVisibility(View.VISIBLE);
            holder.mRltProductItemNamePriceLinearRoot.setVisibility(View.GONE);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putInt("proId", Integer.parseInt(catAssignedProductListDataModel.getProdId()));
                ProductDetailToneFragment productDetailToneFragment = ProductDetailToneFragment.newInstance();
                productDetailToneFragment.setArguments(bundle);
                // Adding Product-Detail-Fragment
                SupportFragmentUtil.getInstance().addFragment(
                        (FragmentActivity) mContext,
                        R.id.activity_dashboard_fragment_container,
                        productDetailToneFragment,
                        String.valueOf(Constants.getFragmentFromClassName(Constants.AppNavigation.strProductDetailFragmentScreen)),
//                        Constants.TAG_PRODUCT_DETAIL,
                        SupportFragmentUtil.ANIMATION_TYPE.NONE);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mProductList.size();
    }

    @Override
    public void onOkHttpStart(int requestId) {

    }

    @Override
    public void onOkHttpSuccess(int requestId, int statusCode, String response) {
        if (requestId == Constants.CODE_WISHLIST_ACTIONS) {
            handleResponseWishListActions(response);
        }
    }

    @Override
    public void onOkHttpFailure(int requestId, int statusCode, String response, Throwable error) {

    }

    @Override
    public void onOkHttpFinish(int requestId) {

    }

    /**
     * @param
     * @return
     * @throws
     * @purpose to initialize Product-List row view.
     */
    public class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout mRltProductItemRoot;
        CardView mCardProductItem;
        RelativeLayout mRltProductItem;
        ImageView mImgProductItemLike;
        ImageView mImgProductItem;
        RelativeLayout mRltProductItemNamePriceLinearRoot;
        RelativeLayout mRltProductItemNamePriceGridRoot;
        CustomTextView mTxtProductItemNameGrid;
        CustomTextView mTxtProductItemPriceGrid;
//        CustomTextView mTxtProductItemNewLabelGrid;
//        CustomTextView mTxtProductItemNameLinear;
//        CustomTextView mTxtProductItemPriceLinear;
//        CustomTextView mTxtProductItemNewLabelLinear;

        public ViewHolder(View itemView) {
            super(itemView);
            findViews(itemView);
        }

        private void findViews(View itemView) {
            mRltProductItemRoot = (RelativeLayout) itemView.findViewById(R.id.rlt_product_item_root);
            mCardProductItem = (CardView) itemView.findViewById(R.id.card_product_item);
            mRltProductItem = (RelativeLayout) itemView.findViewById(R.id.rlt_product_item);
            mImgProductItemLike = (ImageView) itemView.findViewById(R.id.img_product_item_like);
            mImgProductItem = (ImageView) itemView.findViewById(R.id.img_product_item);
            mRltProductItemNamePriceLinearRoot = (RelativeLayout) itemView.findViewById(R.id.rlt_product_item_name_price_linear_root);
            mRltProductItemNamePriceGridRoot = (RelativeLayout) itemView.findViewById(R.id.rlt_product_item_name_price_grid_root);
            mTxtProductItemNameGrid = (CustomTextView) itemView.findViewById(R.id.txt_product_item_name_grid);
            mTxtProductItemPriceGrid = (CustomTextView) itemView.findViewById(R.id.txt_product_item_price_grid);
//            mTxtProductItemNewLabelGrid = (CustomTextView) itemView.findViewById(R.id.txt_product_item_new_label_grid);
//            mTxtProductItemNameLinear = (CustomTextView) itemView.findViewById(R.id.txt_product_item_new_label_linear);
//            mTxtProductItemPriceLinear = (CustomTextView) itemView.findViewById(R.id.txt_product_item_new_label_linear);
//            mTxtProductItemNewLabelLinear = (CustomTextView) itemView.findViewById(R.id.txt_product_item_new_label_linear);
        }
    }

    /**
     * @param strUserId
     * @return
     * @throws
     * @purpose to send request to send request to the server for WishList Actions
     */
    private void callWishListActionsService(String strUserId, String strProId, String strQty, String strFlag) {
        // Check internet connection to proceed
        if (!CommonUtils.isInternetAvailable(mContext)) {
            return;
        }
        new OkHttpRequest(mContext, OkHttpRequest.Method.POST,
                Constants.Urls.WISHLIST_ACTIONS,
                RequestParam.wishListActions(strUserId, strProId, strQty, strFlag),
                RequestParam.getCommonHeaderWithContentType(),
                Constants.CODE_WISHLIST_ACTIONS,
                true,
                okHttpInterface,
                RequestParam.getCommonHeaderWithContentType());
    }

    /**
     * @param output
     * @return
     * @throws
     * @purpose to handle response from server for WishList Actions
     */

    private void handleResponseWishListActions(String output) {
        AppLog.LogE("handleResponseWishListActions", output);
        final Gson gson = new Gson();
        try {
            WishListActionsModel wishListActionsModel = gson.fromJson(output, WishListActionsModel.class);
            if (wishListActionsModel != null) {
                if (wishListActionsModel.getStatus() == 1) {
                    Toast.makeText(mContext, "" + wishListActionsModel.getMsg(), Toast.LENGTH_SHORT).show();
                } else {
                    CommonUtils.displayToast(mContext, "" + wishListActionsModel.getMsg());
                }
            } /*else {
                Toast.makeText(mContext, "" + wishListActionsModel.getMsg(), Toast.LENGTH_SHORT).show();
            }*/
        } catch (Exception e) {
            e.printStackTrace();
            CommonUtils.displayToast(mContext, mContext.getResources().getString(R.string.str_something_went_worng));
        }
    }
}
