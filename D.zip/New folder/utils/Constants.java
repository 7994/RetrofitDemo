package com.builderfly.utils;

import android.support.v4.app.Fragment;

import com.builderfly.sparkup.changepasswordscreens.changepasswordscreentone.ChangePasswordToneFragment;
import com.builderfly.sparkup.checkoutscreens.checkoutscreentone.CheckoutListToneFragment;
import com.builderfly.sparkup.dashboardscreens.dashboardscreentone.DashboardToneActivity;
import com.builderfly.sparkup.filterproductscreens.filterproductscreentone.FilterProductToneFragment;
import com.builderfly.sparkup.forgotpasswordscreens.forgotpasswordtone.ForgotPasswordToneActivity;
import com.builderfly.sparkup.loginscreens.loginscreentone.LoginToneActivity;
import com.builderfly.sparkup.notificationscreens.notificationscreentone.NotificationToneFragment;
import com.builderfly.sparkup.orderlistscreens.orderlistscreentone.CustomerCartListToneFragment;
import com.builderfly.sparkup.orderlistscreens.orderlistscreentone.OrderListToneFragment;
import com.builderfly.sparkup.paymentscreens.paymentscreentone.PaymentToneFragment;
import com.builderfly.sparkup.previewscreens.previewscreentone.PreviewToneActivity;
import com.builderfly.sparkup.productdetailscreens.productdetailscreentone.ProductDetailToneFragment;
import com.builderfly.sparkup.productscreens.productscreentone.ProductListToneFragment;
import com.builderfly.sparkup.profilescreens.profilescreentone.ProfileFavouritesToneFragment;
import com.builderfly.sparkup.profilescreens.profilescreentone.ProfileTOneFragment;
import com.builderfly.sparkup.searchproductscreens.searchproductscreentone.SearchProductToneFragment;
import com.builderfly.sparkup.shopscreens.shopscreentone.ShopListToneFragment;
import com.builderfly.sparkup.signupscreens.signupscreentone.SignUpToneActivity;
import com.builderfly.sparkup.welcomescreens.welcomescreentone.WelcomeToneActivity;
import com.builderfly.sparkup.wishlistscreens.wishlistscreentone.CustomerWishlistToneFragment;

public class Constants {

    // Response Variable
    public static final int SUCCESS_CODE = 1;
    public static final int FAILURE_CODE = 0;
    public static final int SOCIAL_CODE = 2;
    public static final int NOT_FOUND_CODE = 404;
    public static final int NO_CONTENT_CODE = 204;
    public static final int INTERNAL_ERROR_CODE = 500;
    public static final int BAD_REQUEST_CODE = 400;
    public static final int CONFLICT_CODE = 409;
    public static final int UNAUTHORIZED_CODE = 401;

    public static final String SUCCESS = "success";
    public static final String FAILURE = "failed";

    // Custom api code
    public static final int CODE_USER_REGISTERATION = 1;
    public static final int CODE_USER_LOGIN = 2;
    public static final int CODE_ALL_CATEGORIES = 3;
    public static final int CODE_CAT_ASSIGN_PRODUCT_LIST = 4;
    public static final int CODE_PRODUCT_DETAILS = 5;
    public static final int CODE_CART_ACTIONS = 6;
    public static final int CODE_CUSTOMER_ORDER_HISTORY = 7;
    public static final int CODE_CUSTOMER_CART = 8;
    public static final int CODE_CUSTOMER_WISHLIST = 9;
    public static final int CODE_WISHLIST_ACTIONS = 10;
    public static final int CODE_ALL_NOTIFICATIONS = 11;
    public static final int CODE_SEARCH_CATALOGE = 12;
    public static final int CODE_CHANGE_PASSWORD = 13;
    public static final int CODE_MOBILE_CMS_PAGES = 14;
    public static final int CODE_CUSTOMER_ADD_CREATE = 15;
    public static final int CODE_CUSTOMER_ADD_LIST = 16;
    public static final int CODE_CUSTOMER_ADD_UPDATE = 17;
    public static final int CODE_CUSTOMER_ADD_DELETE = 18;
    public static final int CODE_COUPON_ACTIONS = 19;
    public static final int CODE_FORGOT_PASSWORD = 20;
    public static final int CODE_UPDATE_PROFILE = 21;



    public static final String API_KEY = "ICXE1wOphgKgcyMoHr0hVHbbJ";

    // Fragment tag
    public static String TAG_CHECKOUT_LIST = "CheckoutListToneFragment";
    public static String TAG_FILTER_PRODUCT = "FilterProductToneFragment";
    public static String TAG_ORDER_LIST = "OrderListToneFragment";
    public static String TAG_PRODUCT_DETAIL = "ProductDetailToneFragment";
    public static String TAG_PROFILE_FAVOURITES = "ProfileFavouritesToneFragment";
    public static String TAG_PRODUCT_LIST = "ProductListToneFragment";
    public static String TAG_SEARCH_PRODUCT = "SearchProductToneFragment";
    public static String TAG_SHOP_LIST = "ShopListToneFragment";
    public static String TAG_PAYMENT = "PaymentToneFragment";

    // shared preferences key
    public static String PREFERENCE_NAME = "sparkUpPrefs";
    public static String ACCESS_TOKEN = "accessTokenKey";
    public static String DEVICE_TOKEN = "deviceTokenKey";
    public static String USER_ID = "userIdKey";
    public static String USER_NAME = "userNameKey";
    public static String USER_EMAIL = "userEmailKey";
    public static String USER_CART_COUNT = "userCartCount";
    public static String TWITTER_ACCESS_TOCKEN = "twitterAccessTockenKey";
    public static String TWITTER_ACCESS_TOCKEN_SECRET = "twitterAccessTockenSecretKey";
    public static String TWITTER_PROFILE_NAME = "twitterProfileNameKey";
    public static String TWITTER_PROFILE_IMAGE = "twitterProfileImageKey";
    public static String FACEBOOK_PROFILE_NAME = "facebookProfileNameKey";
    public static String FACEBOOK_PROFILE_IMAGE = "facebookProfileImageKey";

    // Activity Names
//    public static String LOGIN_ACTIVITY = "com.builderfly.sparkup.loginscreens.loginscreenone.LoginToneActivity";
//    public static String SIGN_UP_ACTIVITY = "com.builderfly.sparkup.signupscreens.signupscreenone.SignUpToneActivity";
//    public static String WELCOME_ACTIVITY = "com.builderfly.sparkup.welcomescreens.welcomescreenone.WelcomeToneActivity";
//    public static String REVIEW_ACTIVITY = "com.builderfly.sparkup.reviewscreens.reviewscreenone.PreviewToneActivity";
//    public static String DASHBOARD_ACTIVITY = "com.builderfly.sparkup.dashboardscreens.dashboardscreenone.DashboardToneActivity";

    public static class AppNavigation {
        public static String strLoginScreen = LoginToneActivity.class.getName();
        public static String strSignUpScreen = SignUpToneActivity.class.getName();
        public static String strWelcomeScreen = WelcomeToneActivity.class.getName();
        public static String strPreviewScreen = PreviewToneActivity.class.getName();
        public static String strDashboardScreen = DashboardToneActivity.class.getName();
        public static String strForgotPasswordScreen = ForgotPasswordToneActivity.class.getName();

        public static String strCheckoutListFragmentScreen = CheckoutListToneFragment.class.getName();
        public static String strFilterProductFragmentScreen = FilterProductToneFragment.class.getName();
        public static String strOrderListFragmentScreen = OrderListToneFragment.class.getName();
        public static String strCustomerCartListFragmentScreen = CustomerCartListToneFragment.class.getName();
        public static String strProductDetailFragmentScreen = ProductDetailToneFragment.class.getName();
        public static String strProfileFavouritesFragmentScreen = ProfileFavouritesToneFragment.class.getName();
        public static String strProductListFragmentScreen = ProductListToneFragment.class.getName();
        public static String strSearchProductFragmentScreen = SearchProductToneFragment.class.getName();
        public static String strShopListFragmentScreen = ShopListToneFragment.class.getName();
        public static String strWishListFragmentScreen = CustomerWishlistToneFragment.class.getName();
        public static String strProfileFragmentScreen = ProfileTOneFragment.class.getName();
        public static String strPaymentFragmentScreen = PaymentToneFragment.class.getName();
        public static String strNotificationFragmentScreen = NotificationToneFragment.class.getName();
        public static String strChangePasswordFragmentScreen = ChangePasswordToneFragment.class.getName();

//    ParsingToneActivity.class.getName();
    }


    /**
     * this class contains method types of Webservices
     *
     * @author : Jeel Raja
     * @version : 0.0.1
     * @Date :  13/07/2018
     * @since : 0.0.1
     */
    public static class Type {
        public static String post = "POST";
        public static String get = "GET";
    }

    /**
     * this class contains Urls of Webservices
     *
     * @author : Jeel Raja
     * @version : 0.0.1
     * @Date :  13/07/2018
     * @since : 0.0.1
     */
    public static class Urls {
//        static String baseUrl = "http://192.168.15.162/zapstore-ethan/web2/";
        static String baseUrl = "http://202.131.115.108/zapstore/web2/";

        public static String USER_LOGIN = baseUrl + "customerLogin.php";
        public static String USER_REGISTRATION = baseUrl + "customerRegistration.php";
        public static String ALL_CATEGORIES = baseUrl + "allCategory.php";
        public static String CAT_ASSIGN_PRO_LIST = baseUrl + "categoryAssignedProdList.php";
        public static String PRODUCT_DETAILS = baseUrl + "productDetails.php";
        public static String CART_ACTIONS = baseUrl + "cartActions.php";
        public static String CUSTOMER_ORDER_HISTORY = baseUrl + "customerOrderHistoryList.php";
        public static String CUSTOMER_CART = baseUrl + "customerCart.php";
        public static String CUSTOMER_WISHLIST = baseUrl + "customerWishlist.php";
        public static String WISHLIST_ACTIONS = baseUrl + "wishlistActions.php";

        public static String ALL_NOTIFICATIONS = baseUrl + "allNotifications.php";
        public static String SEARCH_CATALOGE = baseUrl + "searchCatalog.php";
        public static String CHANGE_PASSWORD = baseUrl + "changePassword.php";
        public static String MOBILE_CMS_PAGES = baseUrl + "mobileCmsPages.php";
        public static String CUSTOMER_ADDRESS_CREATE = baseUrl + "customerAddressCreate.php";
        public static String CUSTOMER_ADDRESS_LIST = baseUrl + "customerAddressList.php";
        public static String CUSTOMER_ADDRESS_UPDATE = baseUrl + "customerAddressUpdate.php";
        public static String CUSTOMER_ADDRESS_DELETE = baseUrl + "customerAddressDelete.php";
        public static String COUPON_ACTIONS = baseUrl + "couponActions.php";
        public static String FORGOT_PASSWORD = baseUrl + "forgetPassword.php";
        public static String UPDATE_PROFILE = baseUrl + "customerInfoUpdate.php";

    }

    /**
     * this class contains keys of Webservices
     *
     * @author : Jeel Raja
     * @version : 0.0.1
     * @Date :  13/07/2018
     * @since : 0.0.1
     */
    public static class WebServicesKeys {

        public static String mApiKey = "api_key";
        public static String mEmail = "email";
        public static String mPassword = "pass";
        public static String mFname = "fname";
        public static String mLname = "lname";
        public static String mUserId = "userid";
        public static String mCatId = "catid";
        public static String mPro_Id = "prod_id";
        public static String mFlag = "flag";
        public static String mQty = "qty";
        public static String mZipCode = "zipcode";
        public static String mProId = "prodid";

    }

    public static Class<?> getActivityClassName(String activityName) {
        Class<?> classByName = null;
        try {
            classByName = Class.forName(activityName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return classByName;
    }

    public static Fragment getFragmentFromClassName(String strFragmentPath) {
        Fragment classByName = null;
        try {
            classByName = (Fragment) Class.forName(strFragmentPath).newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return classByName;
    }
}
