package com.builderfly.utils;

import android.app.Application;

public class MyApplication extends Application {

    private static final String TAG = MyApplication.class.getSimpleName();

    private static MyApplication mInstance;



    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;

        // Initialize all singleton class

    }

    public static synchronized MyApplication getInstance() {
        return mInstance;
    }

}
