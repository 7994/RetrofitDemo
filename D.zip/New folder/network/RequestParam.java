package com.builderfly.network;

import com.builderfly.utils.Constants;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * RequestParam.java : This class is Used to Send Request body parameters to the server
 *
 * @author : Harsh Patel
 * @version : 1.0.0
 * @Date : 31/05/2018
 */
public class RequestParam {

    //private static CommonUtil mCommonUtil = MyApplication.getInstance().getCommonUtil();

    private static String TAG = RequestParam.class.getSimpleName();

    /*private static TimeUtils mTimeUtil = MyApplication.getInstance().getTimeUtil();
    private static PreferenceManager mPreferenceManager = MyApplication.getInstance().getPreferenceManager();
*/
    public static Map<String, String> getNull() {
        Map<String, String> param = new HashMap<String, String>();
        return param;
    }

    public static Map<String, File> getNullFile() {
        Map<String, File> param = new HashMap<String, File>();
        return param;
    }

    public static Map<String, String> tempParams() {
        Map<String, String> param = new HashMap<String, String>();
        param.put("temp", "temp");
        return param;
    }

    public static Map<String, String> getCommonHeader() {
        Map<String, String> param = new HashMap<String, String>();
        //param.put("Authorization", "" + mPreferenceManager.getAccessToken());
        return param;
    }

    public static Map<String, String> getCommonHeaderFormDataContentType() {
        Map<String, String> param = new HashMap<String, String>();
        //param.put("Authorization", "" + mPreferenceManager.getAccessToken());
        param.put("Content-Type", "multipart/form-data");
        return param;
    }

    public static Map<String, String> getCommonHeaderWithContentType() {
        Map<String, String> param = new HashMap<String, String>();
        //param.put("Authorization", "" + mPreferenceManager.getAccessToken());
        param.put("Content-Type", "application/json");
        return param;
    }

    /* public static Map<String, String> userLogin(String api_key, String emailID, String password) {
         Map<String, String> requestBody = new HashMap<>();
         requestBody.put("api_key", api_key.trim());
         requestBody.put("email", emailID.trim());
         requestBody.put("pass", password.trim());
         return requestBody;
     }
 */
    public static JSONObject userLogin(String apiKey, String emailAddress, String password) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", apiKey.trim());
            jsonRootObject.put("email", emailAddress.trim());
            jsonRootObject.put("pass", password.trim());

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject userRegister(String strEmail, String strFname, String strLname, String Password) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("email", strEmail.trim());
            jsonRootObject.put("fname", strFname.trim());
            jsonRootObject.put("lname", strLname.trim());
            jsonRootObject.put("pass", Password.trim());

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject allCategories(String userId) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("userid",userId);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject productDetails(String strProId, String strUserId) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("prod_id", strProId);
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("userid", strUserId);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject cartActions(String strUserId, String strProId, String strQty, String strFlag, String strZipCode) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("userid", strUserId);
            jsonRootObject.put("prodid", strProId);
            jsonRootObject.put("qty", strQty);
            jsonRootObject.put("flag", strFlag);
            jsonRootObject.put("zipcode", strZipCode);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject customerOrderHistory(String strUserId) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("userid", strUserId);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject catAssignedProductList(String strCatId, String strUserId) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("catid", strCatId);
            jsonRootObject.put("userid", strUserId);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject customerCart(String strUserId) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("userid", strUserId);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject customerWishList(String strUserId) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("userid", strUserId);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject updateProfile(int userID, String email, String fname, String phone) {
        JSONObject requestBody = new JSONObject();
        try {
            requestBody.put("api_key", Constants.API_KEY);
            requestBody.put("email", "" + email.trim());
            requestBody.put("fname", "" + fname.trim());
            requestBody.put("lname", "" + phone.trim());
            requestBody.put("userid", userID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return requestBody;
    }

    public static JSONObject wishListActions(String strUserId, String strProId, String strQty, String strFlag) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("userid", strUserId);
            jsonRootObject.put("prodid", strProId);
            jsonRootObject.put("qty", strQty);
            jsonRootObject.put("flag", strFlag);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject allNotifications(String strUserId) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("userid", strUserId);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject searchCataloge(String strUserId, String strSearchKey) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("userid", strUserId);
            jsonRootObject.put("search_key", strSearchKey);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject changePassword(String strUserId, String strPassword) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("userid", strUserId);
            jsonRootObject.put("password", strPassword);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject forgotPassword(String strEmail) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("email", strEmail);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject mobileCmsPages() {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject customerAddressCreate(String strUserId, String strFname, String strLname, String strST1, String strST2,
                                                   String strCity, String strCountryId, String strRegion, String strRegionId,
                                                   String strPostCode, String strTelephone, String strMobile, String strCompany) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("userid", strUserId);
            jsonRootObject.put("firstname", strFname);
            jsonRootObject.put("lastname", strLname);
            jsonRootObject.put("streetline1", strST1);
            jsonRootObject.put("streetline2", strST2);
            jsonRootObject.put("city", strCity);
            jsonRootObject.put("country_id", strCountryId);
            jsonRootObject.put("region", strRegion);
            jsonRootObject.put("region_id", strRegionId);
            jsonRootObject.put("postcode", strPostCode);
            jsonRootObject.put("telephone", strTelephone);
            jsonRootObject.put("mobile", strMobile);
            jsonRootObject.put("company", strCompany);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }


    public static JSONObject customerAddressList(String strUserId) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("userid", strUserId);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }


    public static JSONObject customerAddressUpdate(String strUserId, String strAddressId, String strFname, String strLname, String strST1, String strST2,
                                                   String strCity, String strCountryId, String strRegion, String strRegionId,
                                                   String strPostCode, String strTelephone, String strMobile, String strCompany) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("userid", strUserId);
            jsonRootObject.put("address_id", strAddressId);
            jsonRootObject.put("firstname", strFname);
            jsonRootObject.put("lastname", strLname);
            jsonRootObject.put("streetline1", strST1);
            jsonRootObject.put("streetline2", strST2);
            jsonRootObject.put("city", strCity);
            jsonRootObject.put("country_id", strCountryId);
            jsonRootObject.put("region", strRegion);
            jsonRootObject.put("region_id", strRegionId);
            jsonRootObject.put("postcode", strPostCode);
            jsonRootObject.put("telephone", strTelephone);
            jsonRootObject.put("mobile", strMobile);
            jsonRootObject.put("company", strCompany);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject customerAddressDelete(String strUserId, String strAddressId) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("userid", strUserId);
            jsonRootObject.put("address_id", strAddressId);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }

    public static JSONObject couponActions(String strUserId, String strCouponCode, String strFlag) {
        JSONObject jsonRootObject = new JSONObject();
        try {
            jsonRootObject.put("api_key", Constants.API_KEY);
            jsonRootObject.put("userid", strUserId);
            jsonRootObject.put("coupon_code", strCouponCode);
            jsonRootObject.put("flag", strFlag);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonRootObject;
    }


}